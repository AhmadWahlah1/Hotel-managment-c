#include<iostream>
using namespace std;
main(){
	int a,b;
	cout<<"Enter two Numbers: "<<endl;
	cin>>a>>b;
	a=a+b;
	b=a-b;
	a=a-b;
    cout<<"After Swapping Numbers :"<<endl;
    cout<<a<<" "<<b;
}
