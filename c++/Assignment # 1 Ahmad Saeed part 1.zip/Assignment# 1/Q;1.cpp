#include<iostream>
using namespace std;
main(){
	cout<<"Subject " <<"\tMarks" <<"\nMathematic\t" <<90<<"\nComputer\t"<<77<<"\nChemistry\t"<<69;
}
