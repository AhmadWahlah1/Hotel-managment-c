#include<iostream>
using namespace std;
main(){
	char ch;
	cout<<"Enter any character:";
	cin>>ch;
	ch++;
	cout<<"Next character is:"<<ch;
}
