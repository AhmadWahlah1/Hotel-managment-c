#include<iostream>
using namespace std;
main(){
	float r,area;
	cout<<"\nEnter radius of circle:";
	cin>>r;
	area=3.14*r*r;
	cout<<"Area of circle:"<<area;
}
