#include<iostream>
using namespace std;
main(){
	float f,c;
	cout<<"\nEnter tempereture in Farenheit : ";
	cin>>f;
	c=5*(f-32)/9;
	cout<<"Tempereature in celcius is : "<<c;
}
