#include<iostream>
using namespace std;
main(){
	int d,rs,s;
	cout<<"Enter any dollor$: ";
	cin>>d;
	cout<<"Enter current value of dollor:$. ";
	cin>>s;
	rs=d*s;
	cout<<"Dollor in Rupees is :Rs. "<<rs;
}
