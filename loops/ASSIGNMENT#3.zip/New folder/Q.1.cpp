#include<iostream>
using namespace std;
main(){
	int a,b;
	a=1;
	b=45;
	while(a<=b){
		if(a%3==0){
			cout<<a<<endl;
		}
		a++;
	}
}