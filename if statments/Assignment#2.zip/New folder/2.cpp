#include<iostream>
using namespace std;
main(){
	int a;
	cout<<"Enter any number: ";
	cin>>a;
	if(a%2==0){
		cout<<"Your number "<<a<<" is even";
	}
	else{
		cout<<"Your number "<<a<<" is odd";
	}
}
